<?php
namespace app\forms;

use std, gui, framework, app;


class MainGlobal extends AbstractForm
{

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        
    }

}
