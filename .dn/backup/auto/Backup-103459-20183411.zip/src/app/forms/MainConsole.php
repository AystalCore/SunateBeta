<?php
namespace app\forms;

use std, gui, framework, app;


class MainConsole extends AbstractForm
{

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        
    }

}
