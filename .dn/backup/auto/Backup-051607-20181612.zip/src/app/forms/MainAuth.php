<?php
namespace app\forms;

use std, gui, framework, app;


class MainAuth extends AbstractForm
{

    /**
     * @event button.action 
     */
    function doButtonAction(UXEvent $e = null)
    {    
        if (file_get_contents('http://acwh.zzz.com.ua/sunate/pass.txt') == $this->edit->text){
            $this->loadForm(MainConsole);
        } else {
            
        }
    }

    /**
     * @event buttonAlt.action 
     */
    function doButtonAltAction(UXEvent $e = null)
    {    
        $this->hide();
    }

}
