<?php
namespace app\modules;

use std, gui, framework, app;


class AppModule extends AbstractModule
{

}