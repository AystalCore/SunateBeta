<?php
namespace app\forms;

use std, gui, framework, app;


class MainConsole extends AbstractForm
{

    /**
     * @event show 
     */
    function doShow(UXWindowEvent $e = null)
    {    
        
    }

    /**
     * @event console.keyDown-Enter 
     */
    function doConsoleKeyDownEnter(UXKeyEvent $e = null)
    {    
        
    }

}
