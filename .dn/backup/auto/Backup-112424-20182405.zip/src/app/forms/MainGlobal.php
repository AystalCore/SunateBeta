<?php
namespace app\forms;

use windows;
use std, gui, framework, app;


class MainGlobal extends AbstractForm
{






}
